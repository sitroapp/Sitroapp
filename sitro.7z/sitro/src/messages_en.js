const mes_en = () => {
    return (
        {
    "active.users": "How are your active users trending over time?",
    "AnalyticsDashboard.usersPages": "How many pages users visit?"
}
);
    };
    export default mes_en;